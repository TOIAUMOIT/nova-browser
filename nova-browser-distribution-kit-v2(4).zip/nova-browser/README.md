# NOVA Browser — multi-platform starter (v0.2)

NOVA is a futuristic multi-platform browser starter with a real Chromium desktop browsing surface and an Android WebView implementation.

## What is implemented
- **Desktop:** Electron + Chromium `WebContentsView`, multiple tabs, navigation, back/forward/reload/home, HTTP(S)-only navigation, isolated renderer context, sandboxed web contents, private in-memory sessions, permission requests denied by default, download save dialog.
- **Android:** multiple WebView tabs, address/search navigation, back/forward/reload, bookmarks and browsing history stored locally, DownloadManager integration, Safe Browsing, file/content access disabled, web permission requests denied by default.
- **Web companion:** futuristic React UI, local bookmarks/history, tab shell, and external-browser handoff. It is not a full browser engine; websites may block iframe embedding.

## Run web companion
```bash
cd apps/web
npm install
npm run dev
```

## Run desktop browser
Start the web UI first:
```bash
cd apps/web
npm install
npm run dev
```
In another terminal:
```bash
cd apps/desktop
npm install
npm start
```
The desktop browser loads the trusted local UI at `http://localhost:5173`. The Chromium page surface is a separate `WebContentsView` layered below the browser controls.

## Android
Open `apps/android` in Android Studio and sync Gradle. Run on an emulator or device with Android 8.0+.

## Security model and limitations
- Desktop remote pages run with `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`, and `webSecurity: true`.
- Desktop accepts only HTTP and HTTPS navigation. Permission requests are denied by default. Private desktop tabs use non-persistent Electron sessions.
- Android denies website permission requests and disables file/content URL access. Safe Browsing is enabled.
- **Android temporary tabs are not fully cookie-isolated.** Do not market them as private/incognito until a robust profile isolation strategy is implemented and tested.
- Android history/bookmarks are local app data; desktop history/bookmark UI persistence is currently in the web UI local storage and needs a production-grade browser database.
- Web companion cannot embed every external site and hands off to the system browser.
- AI, encrypted sync, robust tracker/ad blocking, extension support, split view, full permission prompts, safe-browsing threat feeds, password vault, import/export, and production private-profile management are not implemented yet.
- Do not bypass TLS errors or silently grant website permissions.
- AI page content must be treated as untrusted input; require user consent before sending page content to a model.
- Before release, add automated tests, accessibility review, dependency pinning/SBOM, crash reporting with privacy controls, security audit, and store packaging.

## Validation
Run `node --check apps/desktop/main.js` and `node --check apps/desktop/preload.js` for desktop JavaScript syntax checks. Run `npm run build` in `apps/web` after installing dependencies. Build Android from Android Studio or with Gradle on a configured machine.
