# NOVA — public distribution setup (GitHub + Cloudflare Pages)

## 0. Before publishing
The current project is a development starter, not a release-certified browser. Do not advertise APK/EXE installers until they have been built, tested on real devices, signed, and attached to a GitHub Release.

## 1. Create the GitHub repository
1. Sign in to GitHub and create a repository named `nova-browser`.
2. Choose **Public** if you want anonymous visitors to download public release assets. Do not upload signing keys, passwords, API tokens, personal data, or private certificates.
3. On a computer, extract the NOVA project ZIP.
4. In the project folder, use Git:
   ```bash
   git init
   git add .
   git commit -m "NOVA Browser v0.2 source"
   git branch -M main
   git remote add origin https://github.com/YOUR_GITHUB_USERNAME/nova-browser.git
   git push -u origin main
   ```
   Replace `YOUR_GITHUB_USERNAME` with your **GitHub username**, not your email address.
To find it: sign in to GitHub, open your profile avatar > **Your profile**. The username is the part after `github.com/` in your profile URL. You can also check **Settings > Public profile > Username**.
The email address `duongtamxinhmax3@gmail.com` alone does not identify the GitHub username and should not be embedded in public links.
GitHub's web UI can also upload files, but Git is better for ongoing updates.

## 2. Publish the download page on Cloudflare Pages
1. Sign in to Cloudflare and open **Workers & Pages**.
2. Choose **Create application > Pages > Connect to Git**.
3. Authorize GitHub and select `nova-browser`.
4. Configure:
   - Project name: `nova-browser` (if available; the target hostname will be `nova-browser.pages.dev`)
   - Production branch: `main`
   - Build command: `exit 0`
   - Build output directory: `site-download`
5. Deploy. Cloudflare will give you a `https://<project>.pages.dev` URL.
6. For every future change to `site-download/index.html`, push to `main`; Pages will automatically redeploy.
7. Optional: add a custom domain you own in Pages > Custom domains. A custom domain requires owning the domain and configuring DNS.

Cloudflare Pages Git integration docs:
https://developers.cloudflare.com/pages/configuration/git-integration/
https://developers.cloudflare.com/pages/get-started/git-integration/

## 3. Point the download page to your GitHub account
Edit `site-download/index.html` and replace every `OWNER` with your GitHub username. Commit and push the change. The download URLs intentionally use stable GitHub latest-release asset paths:
- `https://github.com/OWNER/nova-browser/releases/latest/download/NOVA-Android.apk`
- `https://github.com/OWNER/nova-browser/releases/latest/download/NOVA-Windows-Setup.exe`

These links return a file only after a published release contains assets with those exact names.

## 4. Create a GitHub Release
1. Open the repository > Releases > Draft a new release.
2. Create a version tag such as `v0.3.0`.
3. Attach the tested APK and Windows installer with the exact names above.
4. Publish the release. The `releases/latest/download/...` links then resolve to the latest release's matching assets.
5. Also attach SHA-256 checksums and release notes. Keep older releases available for rollback.

## 5. Build and sign real installers
- Android: build a release APK/AAB with Android Studio/Gradle and sign it with your own protected keystore. Never commit the keystore or passwords. Back up the keystore securely; losing it can prevent updates under the same app identity.
- Windows: package the Electron app with a maintained packager (for example electron-builder or Electron Forge), test on clean Windows machines, and sign the installer with a code-signing certificate if distributing broadly.
- Test upgrades, uninstall/reinstall, download integrity, antivirus reputation, permissions, and crash behavior before public release.

## 6. Long-term stability
- Keep the GitHub repository and Cloudflare account under your control; enable two-factor authentication.
- Protect the `main` branch and use version tags/releases.
- Keep a copy of source and release assets in a separate backup.
- Never put secrets in the public repository or frontend HTML.
- `pages.dev` is a provider subdomain, not a domain you own. For a branded permanent URL, buy a domain and attach it to Pages.
- Public GitHub Releases and Cloudflare Pages are dependent on those services' availability and terms; no hosted link can be guaranteed forever.

## 7. Current limitations
The provided project currently has a starter Electron/Android implementation. The web app is a companion interface, not a complete browser engine. No release-signed APK or EXE is included in this repository ZIP yet. AI, E2E sync, mature tracker blocking, extension support, and production security review remain future work.
