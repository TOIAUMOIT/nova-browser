const { contextBridge, ipcRenderer } = require('electron');
const api = Object.freeze({
  getState: () => ipcRenderer.invoke('nova:get-state'),
  newTab: (opts) => ipcRenderer.invoke('nova:new-tab', opts),
  closeTab: (id) => ipcRenderer.invoke('nova:close-tab', id),
  activateTab: (id) => ipcRenderer.invoke('nova:activate-tab', id),
  navigate: (url) => ipcRenderer.invoke('nova:navigate', url),
  back: () => ipcRenderer.invoke('nova:back'),
  forward: () => ipcRenderer.invoke('nova:forward'),
  reload: () => ipcRenderer.invoke('nova:reload'),
  home: () => ipcRenderer.invoke('nova:home'),
  setBounds: (bounds) => ipcRenderer.send('nova:bounds', bounds),
  onState: (fn) => { const h=(_e,v)=>fn(v); ipcRenderer.on('nova:state',h); return ()=>ipcRenderer.removeListener('nova:state',h); },
  onError: (fn) => { const h=(_e,v)=>fn(v); ipcRenderer.on('nova:error',h); return ()=>ipcRenderer.removeListener('nova:error',h); },
  onDownload: (fn) => { const h=(_e,v)=>fn(v); ipcRenderer.on('nova:download',h); return ()=>ipcRenderer.removeListener('nova:download',h); }
});
contextBridge.exposeInMainWorld('novaDesktop', api);
