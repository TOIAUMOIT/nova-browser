const { app, BrowserWindow, WebContentsView, ipcMain, session, dialog, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs');

let win;
const tabs = new Map();
let activeId = null;
let nextId = 1;
let contentBounds = { x: 0, y: 154, width: 1000, height: 600 };
const HOME = 'https://www.google.com';

function safeUrl(raw) {
  try {
    const u = new URL(raw);
    if (!['http:', 'https:'].includes(u.protocol)) return null;
    return u.toString();
  } catch { return null; }
}
function emit(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}
function snapshot() {
  return [...tabs.values()].map(t => ({
    id: t.id, url: t.url, title: t.title || 'Tab mới',
    loading: t.loading, canGoBack: t.view.webContents.canGoBack(),
    canGoForward: t.view.webContents.canGoForward()
  }));
}
function updateTab(t, patch = {}) {
  Object.assign(t, patch);
  emit('nova:state', { tabs: snapshot(), activeId });
}
function setActive(id) {
  const t = tabs.get(Number(id));
  if (!t) return;
  if (activeId && tabs.has(activeId)) win.contentView.removeChildView(tabs.get(activeId).view);
  activeId = t.id;
  win.contentView.addChildView(t.view);
  t.view.setBounds(contentBounds);
  t.view.webContents.focus();
  emit('nova:state', { tabs: snapshot(), activeId });
}
function createTab({ url = '', privateMode = false } = {}) {
  const id = nextId++;
  const partition = privateMode ? `nova-private-${id}` : 'persist:nova';
  const ses = session.fromPartition(partition, { cache: !privateMode });
  const view = new WebContentsView({
    webPreferences: {
      session: ses,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false
    }
  });
  const wc = view.webContents;
  const tab = { id, view, url: '', title: 'Tab mới', loading: false, privateMode };
  tabs.set(id, tab);
  wc.setWindowOpenHandler(({ url: target }) => {
    const valid = safeUrl(target);
    if (valid) createTab({ url: valid, privateMode });
    return { action: 'deny' };
  });
  wc.on('will-navigate', (event, target) => {
    if (!safeUrl(target)) event.preventDefault();
  });
  wc.on('page-title-updated', (_e, title) => updateTab(tab, { title }));
  wc.on('did-start-loading', () => updateTab(tab, { loading: true }));
  wc.on('did-stop-loading', () => updateTab(tab, { loading: false, url: wc.getURL() }));
  wc.on('did-navigate', (_e, target) => updateTab(tab, { url: target }));
  wc.on('did-navigate-in-page', (_e, target) => updateTab(tab, { url: target }));
  wc.on('render-process-gone', () => emit('nova:error', { id, message: 'Trang web gặp sự cố. Bạn có thể tải lại trang.' }));
  wc.session.setPermissionRequestHandler((_wc, permission, callback) => {
    // Deny by default; a reviewed per-site permission UI can explicitly grant later.
    callback(false);
  });
  wc.session.on('will-download', async (_event, item) => {
    const result = await dialog.showSaveDialog(win, {
      defaultPath: path.join(app.getPath('downloads'), item.getFilename())
    });
    if (result.canceled || !result.filePath) { item.cancel(); return; }
    item.setSavePath(result.filePath);
    emit('nova:download', { filename: item.getFilename(), state: 'started' });
    item.once('done', (_e, state) => emit('nova:download', { filename: item.getFilename(), state }));
  });
  if (activeId && tabs.has(activeId)) win.contentView.removeChildView(tabs.get(activeId).view);
  activeId = id;
  win.contentView.addChildView(view);
  view.setBounds(contentBounds);
  const target = safeUrl(url) || HOME;
  wc.loadURL(target).catch(() => emit('nova:error', { id, message: 'Không thể mở địa chỉ này.' }));
  emit('nova:state', { tabs: snapshot(), activeId });
  return id;
}
function closeTab(id) {
  const t = tabs.get(Number(id));
  if (!t) return;
  const wasActive = activeId === t.id;
  if (wasActive) win.contentView.removeChildView(t.view);
  t.view.webContents.close();
  tabs.delete(t.id);
  if (wasActive) {
    activeId = null;
    const fallback = [...tabs.keys()].at(-1);
    if (fallback) setActive(fallback); else createTab();
  } else emit('nova:state', { tabs: snapshot(), activeId });
}
function activeTab() { return tabs.get(activeId); }

function registerIpc() {
  ipcMain.handle('nova:get-state', () => ({ tabs: snapshot(), activeId }));
  ipcMain.handle('nova:new-tab', (_e, opts) => createTab(opts || {}));
  ipcMain.handle('nova:close-tab', (_e, id) => closeTab(id));
  ipcMain.handle('nova:activate-tab', (_e, id) => setActive(id));
  ipcMain.handle('nova:navigate', (_e, raw) => {
    const t = activeTab(); if (!t) return false;
    const value = String(raw || '').trim();
    const target = safeUrl(value) || (value && !value.includes(' ') && value.includes('.') ? safeUrl(`https://${value}`) : null)
      || `${'https://www.google.com/search?q='}${encodeURIComponent(value)}`;
    t.view.webContents.loadURL(target).catch(() => {});
    return true;
  });
  ipcMain.handle('nova:back', () => { const t=activeTab(); if(t?.view.webContents.canGoBack()) t.view.webContents.goBack(); });
  ipcMain.handle('nova:forward', () => { const t=activeTab(); if(t?.view.webContents.canGoForward()) t.view.webContents.goForward(); });
  ipcMain.handle('nova:reload', () => activeTab()?.view.webContents.reload());
  ipcMain.handle('nova:home', () => activeTab()?.view.webContents.loadURL(HOME));
  ipcMain.on('nova:bounds', (_e, b) => {
    if (![b.x,b.y,b.width,b.height].every(Number.isFinite)) return;
    contentBounds = { x: Math.max(0,b.x), y: Math.max(0,b.y), width: Math.max(0,b.width), height: Math.max(0,b.height) };
    const t = activeTab(); if (t) t.view.setBounds(contentBounds);
  });
  ipcMain.handle('nova:open-external', (_e, raw) => {
    const u = safeUrl(raw); if (u) return shell.openExternal(u);
    return false;
  });
}
function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 900, minHeight: 620,
    backgroundColor: '#080b16',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  const dev = process.env.NOVA_DEV_URL || 'http://localhost:5173';
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (event, target) => {
    // The trusted chrome UI must never navigate to arbitrary remote content.
    if (!target.startsWith('http://localhost:5173/')) event.preventDefault();
  });
  win.loadURL(dev);
  win.webContents.once('did-finish-load', () => createTab());
  win.on('resize', () => {
    const t=activeTab(); if(t) t.view.setBounds(contentBounds);
  });
}
app.whenReady().then(() => { registerIpc(); createWindow(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
