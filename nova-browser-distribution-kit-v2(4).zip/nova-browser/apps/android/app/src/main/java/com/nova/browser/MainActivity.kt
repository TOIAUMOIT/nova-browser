package com.nova.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.*
import android.view.ViewGroup
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.graphics.Color
import org.json.JSONArray

class MainActivity : Activity() {
    private data class BrowserTab(val id: Int, val web: WebView, var privateMode: Boolean = false)
    private val tabs = mutableListOf<BrowserTab>()
    private var activeId = 0
    private var nextId = 1
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var tabLabel: TextView
    private lateinit var tabStrip: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("nova", Context.MODE_PRIVATE) }
    private val bookmarks = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bookmarks.addAll(prefs.getStringSet("bookmarks", emptySet()) ?: emptySet())
        buildUi()
        createTab("https://www.google.com")
    }
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8, 12, 24)) }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8, 4, 8, 4) }
        address = EditText(this).apply {
            hint = "Tìm kiếm hoặc nhập địa chỉ"; singleLine = true; textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setBackgroundColor(Color.rgb(24, 35, 57))
            imeOptions = EditorInfo.IME_ACTION_GO
        }
        address.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_GO) { navigate(address.text.toString()); true } else false
        }
        val go = button("Đi") { navigate(address.text.toString()) }
        toolbar.addView(address, LinearLayout.LayoutParams(0, 52, 1f)); toolbar.addView(go)
        root.addView(toolbar)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(4, 2, 4, 2) }
        controls.addView(button("←") { current()?.web?.let { if (it.canGoBack()) it.goBack() } })
        controls.addView(button("→") { current()?.web?.let { if (it.canGoForward()) it.goForward() } })
        controls.addView(button("↻") { current()?.web?.reload() })
        controls.addView(button("☆") { toggleBookmark() })
        controls.addView(button("＋ Tab") { createTab("") })
        controls.addView(button("Tabs") { showTabs() })
        root.addView(controls)
        tabStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(5, 3, 5, 3) }
        root.addView(tabStrip)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        status = TextView(this).apply { text = "NOVA · BẢO MẬT ƯU TIÊN"; textSize = 10f; setTextColor(Color.rgb(95, 220, 190)); setPadding(10, 7, 10, 7) }
        root.addView(status)
        setContentView(root)
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() }
    }
    private fun current() = tabs.find { it.id == activeId }
    private fun createTab(initial: String, privateMode: Boolean = false) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.safeBrowsingEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        if (privateMode) {
            web.settings.cacheMode = WebSettings.LOAD_NO_CACHE
            web.clearCache(true)
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme?.lowercase()
                return scheme != "https" && scheme != "http"
            }
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (activeId == tabs.find { it.web === view }?.id) address.setText(url)
            }
            override fun onPageFinished(view: WebView, url: String) {
                if (activeId == tabs.find { it.web === view }?.id) address.setText(url)
                if (!privateMode) saveHistory(url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) { request.deny() }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
        }
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val req = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                status.text = "Đã đưa tệp vào hàng đợi tải xuống"
            } catch (_: Exception) { status.text = "Không thể tải tệp này" }
        }
        val tab = BrowserTab(nextId++, web, privateMode)
        tabs.add(tab); activate(tab.id)
        if (initial.isNotBlank()) navigate(initial)
    }
    private fun activate(id: Int) {
        val tab = tabs.find { it.id == id } ?: return
        activeId = id; content.removeAllViews()
        (tab.web.parent as? ViewGroup)?.removeView(tab.web)
        content.addView(tab.web, FrameLayout.LayoutParams(-1, -1))
        address.setText(tab.web.url ?: "")
        renderTabs()
    }
    private fun renderTabs() {
        tabStrip.removeAllViews()
        tabs.forEach { tab ->
            val b = button(if (tab.id == activeId) "● ${tab.web.title?.take(12) ?: "Tab"}" else (tab.web.title?.take(12) ?: "Tab")) { activate(tab.id) }
            tabStrip.addView(b)
        }
    }
    private fun showTabs() {
        val labels = tabs.mapIndexed { i, t -> "${i + 1}. ${t.web.title ?: t.web.url ?: "Tab mới"}" }.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Các tab đang mở")
            .setItems(labels) { _, which -> activate(tabs[which].id) }
            .setNegativeButton("Đóng tab hiện tại") { _, _ -> closeCurrent() }
            .setPositiveButton("Tab tạm (không cache)") { _, _ -> createTab("", true) }.show()
    }
    private fun closeCurrent() {
        val tab = current() ?: return
        if (tabs.size == 1) { tab.web.loadUrl("about:blank"); return }
        tabs.remove(tab); content.removeView(tab.web); tab.web.stopLoading(); tab.web.destroy()
        activate(tabs.last().id)
    }
    private fun navigate(input: String) {
        val value = input.trim(); if (value.isEmpty()) return
        val target = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(".") && !value.contains(" ") -> "https://$value"
            else -> "https://www.google.com/search?q=" + Uri.encode(value)
        }
        current()?.web?.loadUrl(target)
    }
    private fun saveHistory(url: String) {
        val old = JSONArray(prefs.getString("history", "[]"))
        val next = JSONArray().put(url)
        for (i in 0 until minOf(old.length(), 199)) if (old.optString(i) != url) next.put(old.optString(i))
        prefs.edit().putString("history", next.toString()).apply()
    }
    private fun toggleBookmark() {
        val url = current()?.web?.url ?: return
        if (!bookmarks.add(url)) bookmarks.remove(url)
        prefs.edit().putStringSet("bookmarks", bookmarks).apply()
        status.text = if (bookmarks.contains(url)) "Đã lưu dấu trang" else "Đã bỏ dấu trang"
    }
    override fun onBackPressed() {
        val web = current()?.web
        if (web != null && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        tabs.forEach { it.web.stopLoading(); it.web.destroy() }
        tabs.clear()
        super.onDestroy()
    }
}
