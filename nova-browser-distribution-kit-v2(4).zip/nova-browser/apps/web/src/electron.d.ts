export {};
declare global {
  interface Window {
    novaDesktop?: {
      getState(): Promise<{tabs: Array<{id:number;url:string;title:string;loading:boolean;canGoBack:boolean;canGoForward:boolean}>;activeId:number|null}>;
      newTab(opts?: {url?:string;privateMode?:boolean}): Promise<number>;
      closeTab(id:number): Promise<void>; activateTab(id:number): Promise<void>;
      navigate(url:string): Promise<boolean>; back(): Promise<void>; forward(): Promise<void>;
      reload(): Promise<void>; home(): Promise<void>; setBounds(b:{x:number;y:number;width:number;height:number}):void;
      onState(fn:(s:any)=>void):()=>void; onError(fn:(e:any)=>void):()=>void; onDownload(fn:(d:any)=>void):()=>void;
    }
  }
}
